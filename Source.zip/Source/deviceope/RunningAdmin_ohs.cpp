#include "RunningAdmin_ohs.h"

/**
 * コンストラクタ
 */
RayReflectAdmin_ohs::RayReflectAdmin_ohs()
    : m() {
}

/**
 * デストラクタ
 */
RayReflectAdmin_ohs::~RayReflectAdmin_ohs() {
}

/**
 * 走行量更新
 */
void RayReflectAdmin_ohs::callRunningValueUpDate() {
}

/**
 * 走行指示
 */
void RayReflectAdmin_ohs::postRunning() {
}

/**
 * 走行実行
 */
void RayReflectAdmin_ohs::callRunning() {
}

/**
 * 走行距離取得
 */
void RayReflectAdmin_ohs::getRunningMileage() {
}

/**
 * 走行角度取得
 */
void RayReflectAdmin_ohs::getRunningAngle() {
}

/**
 * 実指示走行速度取得
 */
void RayReflectAdmin_ohs::getTheRunningPWM() {
}

/**
 * 実指示走行角度取得
 */
void RayReflectAdmin_ohs::getTheRunningVector() {
}