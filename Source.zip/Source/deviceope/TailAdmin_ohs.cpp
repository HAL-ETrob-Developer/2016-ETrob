#include "TailAdmin_ohs.h"

/**
 * コンストラクタ
 */
Balancer_ohs::Balancer_ohs()
    : m() {
}

/**
 * デストラクタ
 */
Balancer_ohs::~Balancer_ohs() {
}

/**
 * 尾角度更新
 */
void Balancer_ohs::callTailDegreeUpDate() {
}

/**
 * 尾角度指示
 */
void Balancer_ohs::postTailDegree() {
}

/**
 * 尾動作実行
 */
void Balancer_ohs::callTailDegree() {
}

/**
 * 尾角度取得
 */
void Balancer_ohs::getTailDegree() {
}