#include "RayReflectAdmin_ohs.h"

/**
 * コンストラクタ
 */
RayReflectAdmin_ohs::RayReflectAdmin_ohs()
    : m() {
}

/**
 * デストラクタ
 */
RayReflectAdmin_ohs::~RayReflectAdmin_ohs() {
}

/**
 * 光学値更新
 */
void RayReflectAdmin_ohs::callReflectValueUpDate() {
}

/**
 * 光学反射値の取得
 */
void RayReflectAdmin_ohs::getReflectValue() {
}

/**
 * 光学センサ状態の取得
 */
void RayReflectAdmin_ohs::getReflectState() {
}