#include "GyroAdmin_ohs.h"

/**
 * コンストラクタ
 */
Balancer_ohs::Balancer_ohs()
    : m() {
}

/**
 * デストラクタ
 */
Balancer_ohs::~Balancer_ohs() {
}

/**
 * ジャイロ値更新
 */
void Balancer_ohs::callGyroUpDate() {
}

/**
 * 値の取得
 */
void Balancer_ohs::getValue() {
}

/**
 * 状態の取得
 */
void Balancer_ohs::getState() {
}