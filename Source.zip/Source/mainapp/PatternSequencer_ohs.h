/* by ohs50465 T.UENO */

#ifndef MAINAPP_PATTERNSEQUENCER_OHS_H_
#define MAINAPP_PATTERNSEQUENCER_OHS_H_

class PatternSequencer_ohs {
public:
    //生成
    PatternSequencer_ohs();
    //デストラクタ 死ぬときあるよ
        virtual ~PatternSequencer_ohs();

    void callPatternRunning();

private:

};

#endif  // MAINAPP_PATTERNSEQUENCER_OHS_H_
