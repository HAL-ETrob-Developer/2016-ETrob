#include "LineTracer_ohs.h"

/**
 * コンストラクタ
 */
LineTracer_ohs::LineTracer_ohs()
    : m() {
}

/**
 * デストラクタ
 */
LineTracer_ohs::~LineTracer_ohs() {
}

/**
 * ライントレース指揮
 */
void LineTracer_ohs::postLineTraceConduct() {
}

/**
 * ライントレース実行
 */
void LineTracer_ohs::callLineTraceAct() {
}

/**
 * ラインエッジトレース
 */
void LineTracer_ohs::execLineEdgeTrace() {
}

/**
 * ラインサーチ
 */
void LineTracer_ohs::execLineSearch() {
}
