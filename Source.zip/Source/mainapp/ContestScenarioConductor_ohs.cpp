#include "ContestScenarioConductor_ohs.h"

/**
 * コンストラクタ
 */
ContestScenarioConductor_ohs::ContestScenarioConductor_ohs()
    : m() {
}

/**
 * デストラクタ
 */
ContestScenarioConductor_ohs::~ContestScenarioConductor_ohs() {
}

/**
 * シナリオ実行
 */
void ContestScenarioConductor_ohs::execScenario() {
}

/**
 * 指揮終了
 */
void ContestScenarioConductor_ohs::quitCommand() {
}

/**
 * シナリオセット
 */
void ContestScenarioConductor_ohs::setScenario() {
}

/**
 * シナリオ更新
 */
void ContestScenarioConductor_ohs::setScenarioUpDate() {
}
