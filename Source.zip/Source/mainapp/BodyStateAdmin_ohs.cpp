#include "BodyStateAdmin_ohs.h"

/**
 * コンストラクタ
 */
BodyStateAdmin_ohs::BodyStateAdmin_ohs()
    : m() {
}

/**
 * デストラクタ
 */
BodyStateAdmin_ohs::~BodyStateAdmin_ohs() {
}

/**
 * 本体状態更新
 */
void BodyStateAdmin_ohs::setBodyStateUpDate() {
}

/**
 * カラーセンサ状態取得
 */
void BodyStateAdmin_ohs::getColorSensorState() {
}

/**
 * バランス状態取得
 */
void BodyStateAdmin_ohs::getBalanceState() {
}

/**
 * 走行距離取得
 */
void BodyStateAdmin_ohs::getMileage() {
}

/**
 * バランス状態取得
 */
void BodyStateAdmin_ohs::getBodyAngle() {
}

/**
 * 走行距離取得
 */
void BodyStateAdmin_ohs::getTailAngle() {
}