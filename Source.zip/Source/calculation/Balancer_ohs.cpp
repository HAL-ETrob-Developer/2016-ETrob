#include "Balancer_ohs.h"

/**
 * コンストラクタ
 */
Balancer_ohs::Balancer_ohs()
    : m() {
}

/**
 * デストラクタ
 */
Balancer_ohs::~Balancer_ohs() {
}

/**
 * モータ出力値計算
 */
void Balancer_ohs::getPWM() {
}