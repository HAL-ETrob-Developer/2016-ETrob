#include "RunningLineCalculator_ohs.h"

/**
 * コンストラクタ
 */
RunningLineCalculator_ohs::RunningLineCalculator_ohs()
    : m() {
}

/**
 * デストラクタ
 */
RunningLineCalculator_ohs::~RunningLineCalculator_ohs() {
}

/**
 * モータ出力値計算
 */
void RunningLineCalculator_ohs::calcRunningLine() {
}