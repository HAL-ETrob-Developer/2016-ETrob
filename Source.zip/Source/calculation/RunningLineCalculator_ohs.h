/* by ohs50465 T.UENO */

#ifndef CALCLATION_RUNNINGLINECALCULATOR_OHS_H_
#define CALCLATION_RUNNINGLINECALCULATOR_OHS_H_

class RunningLineCalculator_ohs {
public:
    //生成
    RunningLineCalculator_ohs();
    //デストラクタ 死ぬときあるよ
        virtual ~RunningLineCalculator_ohs();

    void calcRunningLine();

private:

};

#endif  // RUNNINGLINECALCULATOR_OHS_H_
