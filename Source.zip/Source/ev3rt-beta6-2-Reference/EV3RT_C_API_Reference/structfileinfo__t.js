var structfileinfo__t =
[
    [ "date", "structfileinfo__t.html#a6ab759d8c1c4a264888440e1f0b874fa", null ],
    [ "is_dir", "structfileinfo__t.html#afdc3e9e0bf6660afb965e323b7a31747", null ],
    [ "is_hidden", "structfileinfo__t.html#a5822d4f2e6eb806f147423fc1a56ae6f", null ],
    [ "is_readonly", "structfileinfo__t.html#a820dd1e6bad249e10bb3d237a40d86cd", null ],
    [ "name", "structfileinfo__t.html#a71708dbcdba7461a977328afab955e42", null ],
    [ "size", "structfileinfo__t.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "time", "structfileinfo__t.html#a93658cf9f03a3303cdb292e655c657e7", null ]
];