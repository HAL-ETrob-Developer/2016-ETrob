var struct_s_t_e_p_s_y_n_c =
[
    [ "Brake", "struct_s_t_e_p_s_y_n_c.html#a26d25e195c44ed33132d5a195b241e69", null ],
    [ "Cmd", "struct_s_t_e_p_s_y_n_c.html#a6d0b94f04ea1dc2e87c796f7c6652eec", null ],
    [ "Nos", "struct_s_t_e_p_s_y_n_c.html#a4a9b4b9420f11eb1ae417c76efc26b48", null ],
    [ "Speed", "struct_s_t_e_p_s_y_n_c.html#a6038fc186d48ad57b0fc73782ffe9adf", null ],
    [ "Step", "struct_s_t_e_p_s_y_n_c.html#a59969a18aa16ae5fa50aefbd93c6fac4", null ],
    [ "Turn", "struct_s_t_e_p_s_y_n_c.html#a493caaffd10a0aabe87bb02eb4769a79", null ]
];