var NAVTREE =
[
  [ "EV3RT C API Reference", "index.html", [
    [ "モジュール", "modules.html", "modules" ],
    [ "データ構造", "annotated.html", [
      [ "データ構造", "annotated.html", "annotated_dup" ],
      [ "データ構造索引", "classes.html", null ],
      [ "データフィールド", "functions.html", [
        [ "全て", "functions.html", null ],
        [ "変数", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'クリックで同期表示が無効になります';
var SYNCOFFMSG = 'クリックで同期表示が有効になります';