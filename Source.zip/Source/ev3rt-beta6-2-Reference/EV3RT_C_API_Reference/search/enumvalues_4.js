var searchData=
[
  ['gyro_5fsensor',['GYRO_SENSOR',['../group__ev3sensor.html#gga089f166159fb19f10d81c65c1d8793a2aeaadd6fd17d7b70e48c06b46f2643c5a',1,'ev3api_sensor.h']]]
];
