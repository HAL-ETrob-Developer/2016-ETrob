var searchData=
[
  ['date',['date',['../structfileinfo__t.html#a6ab759d8c1c4a264888440e1f0b874fa',1,'fileinfo_t']]]
];
