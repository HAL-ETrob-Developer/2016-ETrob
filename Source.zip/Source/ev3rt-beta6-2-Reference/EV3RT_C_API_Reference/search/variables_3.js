var searchData=
[
  ['g',['g',['../structrgb__raw__t.html#ad2c8d7f21feee0ce670c72acadf51074',1,'rgb_raw_t']]]
];
