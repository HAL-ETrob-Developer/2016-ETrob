var indexSectionsWithContent =
{
  0: "bcdefghilmnrstuãåæ",
  1: "fimrs",
  2: "ehn",
  3: "bdfginrst",
  4: "bclms",
  5: "bcdeghlmnrtu",
  6: "elãåæ"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "groups"
};

var indexSectionLabels =
{
  0: "全て",
  1: "データ構造",
  2: "関数",
  3: "変数",
  4: "列挙型",
  5: "列挙値",
  6: "グループ"
};

