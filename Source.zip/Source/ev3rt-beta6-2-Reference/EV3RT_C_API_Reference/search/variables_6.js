var searchData=
[
  ['r',['r',['../structrgb__raw__t.html#acfb1795eb860b37ae4a0cf5007525b11',1,'rgb_raw_t']]]
];
