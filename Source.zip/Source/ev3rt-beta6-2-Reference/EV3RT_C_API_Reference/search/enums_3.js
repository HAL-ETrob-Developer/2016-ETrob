var searchData=
[
  ['motor_5fport_5ft',['motor_port_t',['../group__ev3motor.html#ga0f54b84f89f86be757f847d408a2f2f4',1,'ev3api_motor.h']]],
  ['motor_5ftype_5ft',['motor_type_t',['../group__ev3motor.html#ga5f0f3e75314ae11b050988a1ba3e2075',1,'ev3api_motor.h']]]
];
