var searchData=
[
  ['is_5fdir',['is_dir',['../structfileinfo__t.html#afdc3e9e0bf6660afb965e323b7a31747',1,'fileinfo_t']]],
  ['is_5fhidden',['is_hidden',['../structfileinfo__t.html#a5822d4f2e6eb806f147423fc1a56ae6f',1,'fileinfo_t']]],
  ['is_5freadonly',['is_readonly',['../structfileinfo__t.html#a820dd1e6bad249e10bb3d237a40d86cd',1,'fileinfo_t']]]
];
