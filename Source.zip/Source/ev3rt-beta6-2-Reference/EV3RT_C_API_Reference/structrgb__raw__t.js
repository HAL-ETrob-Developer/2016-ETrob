var structrgb__raw__t =
[
    [ "b", "structrgb__raw__t.html#a7976cd62f9b61a65e8104a3cf7c15099", null ],
    [ "g", "structrgb__raw__t.html#ad2c8d7f21feee0ce670c72acadf51074", null ],
    [ "r", "structrgb__raw__t.html#acfb1795eb860b37ae4a0cf5007525b11", null ]
];