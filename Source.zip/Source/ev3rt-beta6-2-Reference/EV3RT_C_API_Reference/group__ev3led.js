var group__ev3led =
[
    [ "ledcolor_t", "group__ev3led.html#ga7866f9f79ea8cacbeb57995cdce3cb2f", [
      [ "LED_OFF", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fafc0ca8cc6cbe215fd3f1ae6d40255b40", null ],
      [ "LED_RED", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fad80f13022b6d309268fadc7b1da89cb9", null ],
      [ "LED_GREEN", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fa0ad916c7f80666dc88f6b5b22a72e742", null ],
      [ "LED_ORANGE", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fa082cd0390f10e6458c4e2a8adf6594c5", null ]
    ] ],
    [ "ev3_led_set_color", "group__ev3led.html#gaa40eed1dd40c81573646f95ec8c427cb", null ]
];