var searchData=
[
  ['listen',['listen',['../classev3api_1_1_sonar_sensor.html#ae3764121e62f0b675567bc26c6ead221',1,'ev3api::SonarSensor']]]
];
