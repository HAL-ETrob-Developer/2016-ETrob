var searchData=
[
  ['reset',['reset',['../classev3api_1_1_clock.html#a3aea9deb2a0bfea9ff05a898f4822e31',1,'ev3api::Clock::reset()'],['../classev3api_1_1_gyro_sensor.html#a3aea9deb2a0bfea9ff05a898f4822e31',1,'ev3api::GyroSensor::reset()'],['../classev3api_1_1_motor.html#a3aea9deb2a0bfea9ff05a898f4822e31',1,'ev3api::Motor::reset()']]]
];
