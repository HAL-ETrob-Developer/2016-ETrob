var searchData=
[
  ['sensor',['Sensor',['../classev3api_1_1_sensor.html#a07b73ea90f6a17cd9cb49444d7bb70ff',1,'ev3api::Sensor']]],
  ['setbrake',['setBrake',['../classev3api_1_1_motor.html#ac05161f4f0a54f9011e96afc0b36f1e1',1,'ev3api::Motor']]],
  ['setcount',['setCount',['../classev3api_1_1_motor.html#af317f15fc5efec2c0bbe275efba894d5',1,'ev3api::Motor']]],
  ['setoffset',['setOffset',['../classev3api_1_1_gyro_sensor.html#ac5e5e38a22d405fe86aa56992ed5fcf4',1,'ev3api::GyroSensor']]],
  ['setpower',['setPower',['../classev3api_1_1_steering.html#a1d154bc23a2a621a810eecd47290c597',1,'ev3api::Steering']]],
  ['setpwm',['setPWM',['../classev3api_1_1_motor.html#a281e8e0218f0d852eef90208a778efb9',1,'ev3api::Motor']]],
  ['sleep',['sleep',['../classev3api_1_1_clock.html#a5801367a6be756fe3a6feb81fd0e94db',1,'ev3api::Clock']]],
  ['sonarsensor',['SonarSensor',['../classev3api_1_1_sonar_sensor.html#a437747fcb3101f97cfb6a4cfb4d339e9',1,'ev3api::SonarSensor']]],
  ['steering',['Steering',['../classev3api_1_1_steering.html#a949e48c5ff386868e918cfb468ac3f1d',1,'ev3api::Steering']]],
  ['stop',['stop',['../classev3api_1_1_motor.html#a8c528baf37154d347366083f0f816846',1,'ev3api::Motor']]]
];
