var searchData=
[
  ['default_5foffset',['DEFAULT_OFFSET',['../classev3api_1_1_gyro_sensor.html#a65bfa1aa06fe7804a64cb583ace4061e',1,'ev3api::GyroSensor']]]
];
