var classev3api_1_1_color_sensor =
[
    [ "ColorSensor", "classev3api_1_1_color_sensor.html#aa04568c513529526d82dab6be9d78f52", null ],
    [ "~ColorSensor", "classev3api_1_1_color_sensor.html#aaf93ee90a67ca04c75c5ea13a8ebf1cf", null ],
    [ "getAmbient", "classev3api_1_1_color_sensor.html#acc44e85bdec1f461287848f422c7d178", null ],
    [ "getBrightness", "classev3api_1_1_color_sensor.html#a69a29c6b39fce66d1add48f98bd7f4f1", null ],
    [ "getColorNumber", "classev3api_1_1_color_sensor.html#a0cb1d918ddc51976152befd4cb7576aa", null ],
    [ "getRawColor", "classev3api_1_1_color_sensor.html#a3847793cb8f59fdd82b0e2862585c548", null ]
];